//square
let side = 5;
let hight = 1.5;
const someConst = 1/2;

let square = someConst*side*hight;

console.log(square);

//about me
const name = "Yaryna";
let age = 23;
const university = "Ivan Franko national university of Lviv";
let profession = "teacher of math";
let company = "Nestle";
let jobPosition = "accountant";
let hobby = "visit a gym";
let color = "green";
let favouriteFruit = "orange";
let season = "winter";
let pet = "dogs";
let favouriteDay = "Saturday";
let favouriteTask = "clean a  house";
let rest = "meeting with friends";
const englishSchool = "'Green Forest'";
let englishLevel = "Intermediate";
const programmingSchool = "LITS";
const programmingLanguage = "Python";
let currentSchol = "Itea";
let futureProfession = "front-end developer";

console.log(`Hello!
My name is ${name}. I am ${age} years old. I studied at ${university} and my profession should be ${profession}, but now i am working at ${company} and my position is ${jobPosition}.
As for me, my favourite color is ${color} because it is associated with grass, favourite fruit is ${favouriteFruit}. I like ${season} because snow.
The favourite day of week is ${favouriteDay} because i like to ${favouriteTask}.The best rest for me is ${rest}.
In free time i ${hobby} and go for a walk with my ${pet}. 
Last year i finished English School ${englishSchool} and now my level is ${englishLevel}. Also at ${programmingSchool} i learned ${programmingLanguage}.
Now i am a student of ${currentSchol} and i hope to be a ${futureProfession}.

${name}.`);